<?php

require_once 'CreerSaeController.php';

$controller = new CreerSaeController();
$controller->createSae();
?>
